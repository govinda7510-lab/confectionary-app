package com.jesaram.confectionery

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Repository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("jesaram_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        val CATEGORIES = listOf(
            "Sweet Suparis",
            "Cold Drinks",
            "Biscuits",
            "Candies",
            "Chips",
            "Ciggrates"
        )

        val DEFAULT_ITEMS = listOf(
            ConfectioneryItem(id = "item-1", name = "Shahi Sweet Supari (Premium)", price = 50.0, category = "Sweet Suparis"),
            ConfectioneryItem(id = "item-2", name = "Tulsi Sweet Supari Pack", price = 30.0, category = "Sweet Suparis"),
            ConfectioneryItem(id = "item-3", name = "Aroma Mint Supari", price = 20.0, category = "Sweet Suparis"),
            ConfectioneryItem(id = "item-4", name = "Coca Cola 300ml Can", price = 120.0, category = "Cold Drinks"),
            ConfectioneryItem(id = "item-5", name = "Sprite 500ml Can", price = 150.0, category = "Cold Drinks"),
            ConfectioneryItem(id = "item-6", name = "Mineral Water 1L", price = 80.0, category = "Cold Drinks"),
            ConfectioneryItem(id = "item-7", name = "Baker's Butter Cookies", price = 180.0, category = "Biscuits"),
            ConfectioneryItem(id = "item-8", name = "Chocolate Chip Biscuits", price = 140.0, category = "Biscuits"),
            ConfectioneryItem(id = "item-9", name = "Zeera Plus Salted Biscuits", price = 100.0, category = "Biscuits"),
            ConfectioneryItem(id = "item-10", name = "Creamy Butterscotch Candy", price = 10.0, category = "Candies"),
            ConfectioneryItem(id = "item-11", name = "Mango Tango Tangy Candy", price = 5.0, category = "Candies"),
            ConfectioneryItem(id = "item-12", name = "Spicy Masala Potato Chips", price = 80.0, category = "Chips"),
            ConfectioneryItem(id = "item-13", name = "Classic Salted Wafers", price = 70.0, category = "Chips"),
            ConfectioneryItem(id = "item-14", name = "Gold Flake Premium (Single)", price = 30.0, category = "Ciggrates"),
            ConfectioneryItem(id = "item-15", name = "Marlboro Gold Box", price = 550.0, category = "Ciggrates")
        )
    }

    fun getItems(): List<ConfectioneryItem> {
        val json = prefs.getString("items", null) ?: return DEFAULT_ITEMS
        return try {
            val type = object : TypeToken<List<ConfectioneryItem>>() {}.type
            gson.fromJson(json, type) ?: DEFAULT_ITEMS
        } catch (e: Exception) {
            DEFAULT_ITEMS
        }
    }

    fun saveItems(items: List<ConfectioneryItem>) {
        prefs.edit().putString("items", gson.toJson(items)).apply()
    }

    fun getTransactions(): List<ConfectioneryTransaction> {
        val json = prefs.getString("transactions", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<ConfectioneryTransaction>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveTransactions(transactions: List<ConfectioneryTransaction>) {
        prefs.edit().putString("transactions", gson.toJson(transactions)).apply()
    }
}
