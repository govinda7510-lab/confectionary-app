package com.jesaram.confectionery.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.jesaram.confectionery.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    itemsList: List<ConfectioneryItem>,
    onUpdateItems: (List<ConfectioneryItem>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isFormOpen by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<ConfectioneryItem?>(null) }

    // Form states
    var itemName by remember { mutableStateOf("") }
    var itemCategory by remember { mutableStateOf(Repository.CATEGORIES[0]) }
    var itemPrice by remember { mutableStateOf("") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    // Bulk price states
    var bulkAdjustType by remember { mutableStateOf("Percentage Increase (+%)") }
    var bulkAdjustAmount by remember { mutableStateOf("") }
    var bulkAdjustCategory by remember { mutableStateOf("All Categories") }
    var bulkCatDropdownExpanded by remember { mutableStateOf(false) }
    var bulkTypeDropdownExpanded by remember { mutableStateOf(false) }

    // Trigger form for add
    fun openAddForm() {
        editingItem = null
        itemName = ""
        itemCategory = Repository.CATEGORIES[0]
        itemPrice = ""
        isFormOpen = true
    }

    // Trigger form for edit
    fun openEditForm(item: ConfectioneryItem) {
        editingItem = item
        itemName = item.name
        itemCategory = item.category
        itemPrice = item.price.toString()
        isFormOpen = true
    }

    val filteredItems = itemsList.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search & Add Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search items...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Button(
                onClick = { openAddForm() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Icon(Icons.Default.PlusOne, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Item", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Bulk Adjustment Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    "Bulk Price Adjustment Tool",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Category Selection
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { bulkCatDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = bulkAdjustCategory,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        DropdownMenu(
                            expanded = bulkCatDropdownExpanded,
                            onDismissRequest = { bulkCatDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Categories") },
                                onClick = {
                                    bulkAdjustCategory = "All Categories"
                                    bulkCatDropdownExpanded = false
                                }
                            )
                            Repository.CATEGORIES.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        bulkAdjustCategory = cat
                                        bulkCatDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Adjustment Type Selection
                    Box(modifier = Modifier.weight(1.2f)) {
                        OutlinedButton(
                            onClick = { bulkTypeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = bulkAdjustType,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        val adjustmentTypes = listOf(
                            "Percentage Increase (+%)",
                            "Percentage Decrease (-%)",
                            "Flat Increase (+Rs)",
                            "Flat Decrease (-Rs)"
                        )
                        DropdownMenu(
                            expanded = bulkTypeDropdownExpanded,
                            onDismissRequest = { bulkTypeDropdownExpanded = false }
                        ) {
                            adjustmentTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        bulkAdjustType = type
                                        bulkTypeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Price input
                    OutlinedTextField(
                        value = bulkAdjustAmount,
                        onValueChange = { bulkAdjustAmount = it },
                        modifier = Modifier
                            .weight(0.7f)
                            .height(48.dp),
                        placeholder = { Text("Value", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        val amt = bulkAdjustAmount.toDoubleOrNull() ?: return@Button
                        val updated = itemsList.map { item ->
                            val matchCategory = bulkAdjustCategory == "All Categories" || item.category == bulkAdjustCategory
                            if (matchCategory) {
                                var newPrice = item.price
                                when (bulkAdjustType) {
                                    "Percentage Increase (+%)" -> newPrice += (newPrice * (amt / 100.0))
                                    "Percentage Decrease (-%)" -> newPrice -= (newPrice * (amt / 100.0))
                                    "Flat Increase (+Rs)" -> newPrice += amt
                                    "Flat Decrease (-Rs)" -> newPrice -= amt
                                }
                                if (newPrice < 0.0) newPrice = 0.0
                                // Round to nearest integer for Rs.
                                item.copy(price = Math.round(newPrice).toDouble())
                            } else {
                                item
                            }
                        }
                        onUpdateItems(updated)
                        bulkAdjustAmount = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.TrendingUp, contentDescription = "Apply")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Apply Adjustments", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Inventory Items Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Active Inventory (${filteredItems.size} items)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), modifier = Modifier.padding(bottom = 8.dp))

        // Inventory List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredItems, key = { it.id }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.category,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Text(
                            text = "Rs. ${item.price.toInt()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }

                    Row {
                        IconButton(onClick = { openEditForm(item) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                val updated = itemsList.filter { it.id != item.id }
                                onUpdateItems(updated)
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Dialog Form
    if (isFormOpen) {
        Dialog(onDismissRequest = { isFormOpen = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = if (editingItem != null) "Edit Item Details" else "Add New Item",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Name Input
                    OutlinedTextField(
                        value = itemName,
                        onValueChange = { itemName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        label = { Text("Item Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Price Input
                    OutlinedTextField(
                        value = itemPrice,
                        onValueChange = { itemPrice = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        label = { Text("Price (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Category Dropdown Selection
                    Text("Category", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                    Box(modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
                        OutlinedButton(
                            onClick = { categoryDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(itemCategory, color = MaterialTheme.colorScheme.onBackground)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = categoryDropdownExpanded,
                            onDismissRequest = { categoryDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Repository.CATEGORIES.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        itemCategory = cat
                                        categoryDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Form Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isFormOpen = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                if (itemName.isBlank()) return@Button
                                val pr = itemPrice.toDoubleOrNull() ?: return@Button

                                if (editingItem != null) {
                                    // Update
                                    val updated = itemsList.map {
                                        if (it.id == editingItem!!.id) {
                                            it.copy(name = itemName, price = pr, category = itemCategory)
                                        } else {
                                            it
                                        }
                                    }
                                    onUpdateItems(updated)
                                } else {
                                    // Add
                                    val newItem = ConfectioneryItem(
                                        name = itemName,
                                        price = pr,
                                        category = itemCategory
                                    )
                                    onUpdateItems(itemsList + newItem)
                                }

                                isFormOpen = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
