package com.jesaram.confectionery.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CocoaDark = Color(0xFF3E2723)
val CocoaMedium = Color(0xFF4E342E)
val CocoaLight = Color(0xFFD7CCC8)
val WarmBackground = Color(0xFFFDFBF7)
val WarmSurface = Color(0xFFFFFFFF)
val CandyRose = Color(0xFFEC407A)
val CandyRoseDark = Color(0xFFD81B60)

private val LightColorScheme = lightColorScheme(
    primary = CocoaDark,
    onPrimary = Color.White,
    secondary = CandyRose,
    onSecondary = Color.White,
    background = WarmBackground,
    onBackground = Color(0xFF1C1917),
    surface = WarmSurface,
    onSurface = Color(0xFF1C1917),
    surfaceVariant = Color(0xFFF5F2EB),
    onSurfaceVariant = Color(0xFF57534E),
    outline = Color(0xFFD6D3D1)
)

@Composable
fun JesaramTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
