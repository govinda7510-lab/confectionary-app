package com.jesaram.confectionery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jesaram.confectionery.PrinterState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PrinterScreen(
    printerState: PrinterState,
    onUpdatePrinterState: (PrinterState) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Auto scroll logs to bottom
    LaunchedEffect(printerState.logs.size) {
        if (printerState.logs.isNotEmpty()) {
            listState.animateScrollToItem(printerState.logs.size - 1)
        }
    }

    fun getTime(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Status Panel Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Thermal Printer Settings",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Model: Bluetooth SPP PT-210 (58mm)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    // Connection Dot status indicator
                    Surface(
                        modifier = Modifier.size(12.dp),
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = when {
                            printerState.isConnected -> Color(0xFF4CAF50)
                            printerState.isConnecting -> Color(0xFFFFC107)
                            else -> Color(0xFFF44336)
                        }
                    ) { }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = "Printer status icon",
                        tint = if (printerState.isConnected) MaterialTheme.colorScheme.primary else Color.Gray,
                        modifier = Modifier.size(40.dp)
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when {
                                printerState.isConnected -> "CONNECTED: ${printerState.deviceName}"
                                printerState.isConnecting -> "Scanning & Connecting..."
                                else -> "PRINTER OFFLINE"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (printerState.isConnected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = when {
                                printerState.isConnected -> "Status: Ready • Battery: 85% • Mode: SPP"
                                printerState.isConnecting -> "Locating SPP UUID 18f0..."
                                else -> "Connect device to enable thermal print-outs."
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Connection Action row buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!printerState.isConnected && !printerState.isConnecting) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val newLogs = printerState.logs.toMutableList()
                                    newLogs.add("[${getTime()}] Starting BLE discovery scans...")
                                    onUpdatePrinterState(printerState.copy(isConnecting = true, logs = newLogs))

                                    delay(1000)

                                    val scanLogs = printerState.logs.toMutableList()
                                    scanLogs.add("[${getTime()}] Starting BLE discovery scans...")
                                    scanLogs.add("[${getTime()}] BLE Scan discovered device: Jesaram-Thermal PT-210")
                                    onUpdatePrinterState(printerState.copy(isConnecting = true, logs = scanLogs))

                                    delay(1000)

                                    val finalLogs = scanLogs.toMutableList()
                                    finalLogs.add("[${getTime()}] Pairing PIN verified automatically...")
                                    finalLogs.add("[${getTime()}] Socket port open on SPP GATT profile UUID 18f0.")
                                    finalLogs.add("[${getTime()}] Printer status: Ready, Online (battery 85%)")
                                    onUpdatePrinterState(
                                        PrinterState(
                                            isConnected = true,
                                            isConnecting = false,
                                            deviceName = "Jesaram-Thermal PT-210",
                                            logs = finalLogs
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.Bluetooth, contentDescription = "Connect", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan & Connect", fontSize = 11.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                val dLogs = printerState.logs.toMutableList()
                                dLogs.add("[${getTime()}] Socket disconnected by user action.")
                                dLogs.add("[${getTime()}] Printer is now Offline.")
                                onUpdatePrinterState(
                                    PrinterState(
                                        isConnected = false,
                                        isConnecting = false,
                                        deviceName = null,
                                        logs = dLogs
                                    )
                                )
                            },
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.outline)
                        ) {
                            Icon(Icons.Default.BluetoothDisabled, contentDescription = "Disconnect", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Disconnect", fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = {
                            if (!printerState.isConnected) return@Button
                            val selfTestLogs = printerState.logs.toMutableList()
                            selfTestLogs.add("[${getTime()}] Initiating self test printing loop...")
                            selfTestLogs.add("[Printer] ================================")
                            selfTestLogs.add("[Printer]    JESARAM PT-210 SELF TEST     ")
                            selfTestLogs.add("[Printer] ================================")
                            selfTestLogs.add("[Printer] Firmware: v4.11-b12             ")
                            selfTestLogs.add("[Printer] Buffer Size: 4096 bytes         ")
                            selfTestLogs.add("[Printer] Encoding: ESC/POS (UTF-8)       ")
                            selfTestLogs.add("[Printer] Paper Size: 58mm / 384 dots     ")
                            selfTestLogs.add("[Printer] Print Density: 100%             ")
                            selfTestLogs.add("[Printer] Fonts: Courier, Sans, Monospace")
                            selfTestLogs.add("[Printer] Test printing: OK               ")
                            selfTestLogs.add("[Printer] ================================")
                            selfTestLogs.add("[${getTime()}] Self test printed successfully.")
                            onUpdatePrinterState(printerState.copy(logs = selfTestLogs))
                        },
                        enabled = printerState.isConnected,
                        modifier = Modifier.weight(1.1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Handyman, contentDescription = "Self Test", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Self-Test", fontSize = 11.sp)
                    }
                }
            }
        }

        // Terminal Logs Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Live Thermal Terminal Log stream",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            TextButton(
                onClick = {
                    onUpdatePrinterState(printerState.copy(logs = listOf("[${getTime()}] Terminal Log Cleared.")))
                }
            ) {
                Text("Clear Log", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
            }
        }

        // Terminal Logs Panel Box (Dark Console)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF1E1E1E), RoundedCornerShape(16.dp))
                .border(2.dp, Color(0xFF333333), RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(printerState.logs) { log ->
                    Text(
                        text = log,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = when {
                            log.contains("[System Error]") || log.contains("failed") -> Color(0xFFFF5252)
                            log.contains("[Printer]") -> Color(0xFF81C784)
                            log.contains("[System]") || log.contains("[") -> Color(0xFF64B5F6)
                            else -> Color(0xFFE0E0E0)
                        }
                    )
                }
            }
        }
    }
}
