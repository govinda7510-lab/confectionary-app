package com.jesaram.confectionery.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.widget.Toast
import com.jesaram.confectionery.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    itemsList: List<ConfectioneryItem>,
    appLanguage: String,
    onUpdateItems: (List<ConfectioneryItem>) -> Unit,
    onRestoreBackup: (List<ConfectioneryItem>, List<ConfectioneryTransaction>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isFormOpen by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<ConfectioneryItem?>(null) }

    // Form states
    var itemName by remember { mutableStateOf("") }
    var itemCategory by remember { mutableStateOf(Repository.CATEGORIES[0]) }
    var itemPrice by remember { mutableStateOf("") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    // Bulk price states
    var bulkAdjustType by remember { mutableStateOf("Percentage Increase (+%)") }
    var bulkAdjustAmount by remember { mutableStateOf("") }
    var bulkAdjustCategory by remember { mutableStateOf("All Categories") }
    var bulkCatDropdownExpanded by remember { mutableStateOf(false) }
    var bulkTypeDropdownExpanded by remember { mutableStateOf(false) }

    val isUrdu = appLanguage == "Urdu"
    val context = LocalContext.current

    // Trigger form for add
    fun openAddForm() {
        editingItem = null
        itemName = ""
        itemCategory = Repository.CATEGORIES[0]
        itemPrice = ""
        isFormOpen = true
    }

    // Trigger form for edit
    fun openEditForm(item: ConfectioneryItem) {
        editingItem = item
        itemName = item.name
        itemCategory = item.category
        itemPrice = item.price.toString()
        isFormOpen = true
    }

    val filteredItems = itemsList.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search & Add Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { 
                        Text(
                            if (isUrdu) "آئٹم تلاش کریں..." else "Search items...", 
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        ) 
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Button(
                    onClick = { openAddForm() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isUrdu) "نیا آئٹم" else "Add Item", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Bulk Adjustment Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (isUrdu) "قیمتوں میں تبدیلی کا ٹول (Bulk adjustment)" else "Bulk Price Adjustment Tool",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Category Selection
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(
                                onClick = { bulkCatDropdownExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = if (isUrdu && bulkAdjustCategory == "All Categories") "تمام کیٹیگریز" else bulkAdjustCategory,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            DropdownMenu(
                                expanded = bulkCatDropdownExpanded,
                                onDismissRequest = { bulkCatDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (isUrdu) "تمام کیٹیگریز (All)" else "All Categories") },
                                    onClick = {
                                        bulkAdjustCategory = "All Categories"
                                        bulkCatDropdownExpanded = false
                                    }
                                )
                                Repository.CATEGORIES.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat) },
                                        onClick = {
                                            bulkAdjustCategory = cat
                                            bulkCatDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Adjustment Type Selection
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedButton(
                                onClick = { bulkTypeDropdownExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = if (isUrdu) {
                                        when (bulkAdjustType) {
                                            "Percentage Increase (+%)" -> "فیصد اضافہ (+%)"
                                            "Percentage Decrease (-%)" -> "فیصد کمی (-%)"
                                            "Flat Increase (+Rs)" -> "رقم اضافہ (+Rs)"
                                            else -> "رقم کمی (-Rs)"
                                        }
                                    } else bulkAdjustType,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            val adjustmentTypes = listOf(
                                "Percentage Increase (+%)",
                                "Percentage Decrease (-%)",
                                "Flat Increase (+Rs)",
                                "Flat Decrease (-Rs)"
                            )
                            DropdownMenu(
                                expanded = bulkTypeDropdownExpanded,
                                onDismissRequest = { bulkTypeDropdownExpanded = false }
                            ) {
                                adjustmentTypes.forEach { type ->
                                    DropdownMenuItem(
                                        text = { 
                                            Text(
                                                if (isUrdu) {
                                                    when (type) {
                                                        "Percentage Increase (+%)" -> "فیصد اضافہ (+%)"
                                                        "Percentage Decrease (-%)" -> "فیصد کمی (-%)"
                                                        "Flat Increase (+Rs)" -> "رقم اضافہ (+Rs)"
                                                        else -> "رقم کمی (-Rs)"
                                                    }
                                                } else type
                                            ) 
                                        },
                                        onClick = {
                                            bulkAdjustType = type
                                            bulkTypeDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Price input
                        OutlinedTextField(
                            value = bulkAdjustAmount,
                            onValueChange = { bulkAdjustAmount = it },
                            modifier = Modifier
                                .weight(0.7f)
                                .height(44.dp),
                            placeholder = { Text(if (isUrdu) "رقم" else "Val", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val amt = bulkAdjustAmount.toDoubleOrNull() ?: return@Button
                            val updated = itemsList.map { item ->
                                val matchCategory = bulkAdjustCategory == "All Categories" || item.category == bulkAdjustCategory
                                if (matchCategory) {
                                    var newPrice = item.price
                                    when (bulkAdjustType) {
                                        "Percentage Increase (+%)" -> newPrice += (newPrice * (amt / 100.0))
                                        "Percentage Decrease (-%)" -> newPrice -= (newPrice * (amt / 100.0))
                                        "Flat Increase (+Rs)" -> newPrice += amt
                                        "Flat Decrease (-Rs)" -> newPrice -= amt
                                    }
                                    if (newPrice < 0.0) newPrice = 0.0
                                    item.copy(price = Math.round(newPrice).toDouble())
                                } else {
                                    item
                                }
                            }
                            onUpdateItems(updated)
                            bulkAdjustAmount = ""
                            Toast.makeText(context, if (isUrdu) "تبدیلی لاگو کر دی گئی ہے!" else "Bulk adjustments applied successfully!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.TrendingUp, contentDescription = "Apply")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isUrdu) "تبدیلی لاگو کریں" else "Apply Adjustments", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Data Backup, Cloud Storage & Restore Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = "Backup", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isUrdu) "بیک اپ اور ڈیٹا سیکیورٹی (Google Drive & Terabox)" else "Data Backup & Recovery (Google Drive/Terabox)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Export button
                        Button(
                            onClick = {
                                val repository = Repository(context)
                                val success = FileUtils.exportBackup(context, repository.getBackupDataJson())
                                if (success) {
                                    Toast.makeText(context, if (isUrdu) "کامیابی سے بیک اپ فائل بنا دی گئی ہے!" else "Backup created successfully in Downloads!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Failed to create backup", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Export", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isUrdu) "بیک اپ فائل بنائیں" else "Export Backup", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Import button
                        Button(
                            onClick = {
                                val backupJson = FileUtils.importBackup(context)
                                if (backupJson != null) {
                                    val repository = Repository(context)
                                    val success = repository.restoreBackupDataJson(backupJson)
                                    if (success) {
                                        onRestoreBackup(repository.getItems(), repository.getTransactions())
                                        Toast.makeText(context, if (isUrdu) "بیک اپ کامیابی سے بحال ہو گیا ہے!" else "Data backup restored successfully!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Invalid backup file content", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, if (isUrdu) "کوئی بیک اپ فائل نہیں ملی۔" else "No backup file found in Downloads!", Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.Upload, contentDescription = "Import", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isUrdu) "بیک اپ بحال کریں" else "Import Backup", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Instructions in both languages
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "💡 Continuous Backup Guide (Google Drive & Terabox):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Your app data is automatically saved locally on every transaction! To make backups 100% free & secure against device deletion, simply locate 'Jesaram_Confectionery_Backup.json' inside your phone's 'Downloads' folder and upload it directly to your free Google Drive or Terabox account. To restore, just download it back into 'Downloads' and click 'Import Backup' above!",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 14.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "💡 مسلسل بیک اپ اور ریکارڈ کی حفاظت:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ہر فروخت کے بعد آپ کے بلوں کا بیک اپ خود بخود بن جاتا ہے! اپنے قیمتی ریکارڈ کو محفوظ رکھنے کے لیے، اپنے فون کے 'Downloads' فولڈر سے بیک اپ فائل 'Jesaram_Confectionery_Backup.json' کو اپنے گوگل ڈرائیو یا Terabox پر اپ لوڈ کریں۔ دوبارہ ریکارڈ لانے کے لیے، فائل کو ڈاؤن لوڈ کریں اور اوپر 'بیک اپ بحال کریں' پر کلک کریں!",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Inventory Items Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isUrdu) "آئٹمز کی فہرست (${filteredItems.size} آئٹم)" else "Active Inventory (${filteredItems.size} items)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), modifier = Modifier.padding(top = 4.dp))
        }

        // Inventory List items in LazyColumn context
        if (filteredItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (isUrdu) "کوئی آئٹم نہیں ملا۔" else "No inventory items matches your search.")
                }
            }
        } else {
            items(filteredItems, key = { it.id }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.category,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Text(
                            text = "Rs. ${item.price.toInt()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }

                    Row {
                        IconButton(onClick = { openEditForm(item) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                val updated = itemsList.filter { it.id != item.id }
                                onUpdateItems(updated)
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Dialog Form
    if (isFormOpen) {
        Dialog(onDismissRequest = { isFormOpen = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = if (editingItem != null) (if (isUrdu) "آئٹم میں ترمیم کریں" else "Edit Item Details") else (if (isUrdu) "نیا آئٹم شامل کریں" else "Add New Item"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Name Input
                    OutlinedTextField(
                        value = itemName,
                        onValueChange = { itemName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        label = { Text(if (isUrdu) "آئٹم کا نام" else "Item Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Price Input
                    OutlinedTextField(
                        value = itemPrice,
                        onValueChange = { itemPrice = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        label = { Text(if (isUrdu) "قیمت (Rs.)" else "Price (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Category Dropdown Selection
                    Text(if (isUrdu) "کیٹیگری" else "Category", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                    Box(modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
                        OutlinedButton(
                            onClick = { categoryDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(itemCategory, color = MaterialTheme.colorScheme.onBackground)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = categoryDropdownExpanded,
                            onDismissRequest = { categoryDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Repository.CATEGORIES.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        itemCategory = cat
                                        categoryDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Form Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isFormOpen = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isUrdu) "منسوخ" else "Cancel")
                        }

                        Button(
                            onClick = {
                                if (itemName.isBlank()) return@Button
                                val pr = itemPrice.toDoubleOrNull() ?: return@Button

                                if (editingItem != null) {
                                    // Update
                                    val updated = itemsList.map {
                                        if (it.id == editingItem!!.id) {
                                            it.copy(name = itemName, price = pr, category = itemCategory)
                                        } else {
                                            it
                                        }
                                    }
                                    onUpdateItems(updated)
                                } else {
                                    // Add
                                    val newItem = ConfectioneryItem(
                                        name = itemName,
                                        price = pr,
                                        category = itemCategory
                                    )
                                    onUpdateItems(itemsList + newItem)
                                }

                                isFormOpen = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isUrdu) "محفوظ کریں" else "Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
