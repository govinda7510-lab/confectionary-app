package com.jesaram.confectionery

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.util.UUID

object BluetoothPrinterHelper {

    // Standard SPP UUID for Bluetooth serial board connection
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    /**
     * Check if Bluetooth permissions are granted.
     */
    fun hasBluetoothPermissions(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Get a list of paired bluetooth thermal printers.
     */
    @SuppressLint("MissingPermission")
    fun getPairedPrinters(context: Context): List<BluetoothDevice> {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bluetoothManager.adapter ?: return emptyList()

        if (!adapter.isEnabled) {
            return emptyList()
        }

        if (!hasBluetoothPermissions(context)) {
            return emptyList()
        }

        // Filter devices that resemble printers or are paired
        return adapter.bondedDevices.toList()
    }

    /**
     * Prints a bitmap on a Bluetooth ESC/POS thermal printer.
     */
    @SuppressLint("MissingPermission")
    fun printBitmap(context: Context, deviceAddress: String, bitmap: Bitmap, onStatusUpdate: (String) -> Unit): Boolean {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bluetoothManager.adapter ?: run {
            onStatusUpdate("Bluetooth not supported on this device.")
            return false
        }

        if (!hasBluetoothPermissions(context)) {
            onStatusUpdate("Bluetooth permission not granted.")
            return false
        }

        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            onStatusUpdate("Connecting to printer...")
            val device = adapter.getRemoteDevice(deviceAddress)
            
            // Create Socket
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()
            outputStream = socket.outputStream

            onStatusUpdate("Sending print data stream...")
            
            // Initialize printer
            outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @
            
            // Generate print bytes from receipt bitmap
            val printBytes = convertBitmapToEscPosBytes(bitmap)
            
            // Write bytes
            outputStream.write(printBytes)
            
            // Extra line feeds to feed the receipt past the tear-off bar
            outputStream.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x0A, 0x0A))
            outputStream.flush()

            onStatusUpdate("Receipt printed successfully!")
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            onStatusUpdate("Error: ${e.localizedMessage ?: "Failed to connect"}")
            return false
        } finally {
            try {
                outputStream?.close()
                socket?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Converts a standard colored Bitmap to ESC/POS Monochrome raster image command bytes (GS v 0).
     */
    private fun convertBitmapToEscPosBytes(bitmap: Bitmap): ByteArray {
        // ESC/POS thermal printers usually support 58mm roll (approx 384 pixels printable width)
        // Let's scale down our bitmap to 384px width to fit the 58mm roll perfectly.
        val targetWidth = 384
        val scale = targetWidth.toFloat() / bitmap.width
        val targetHeight = (bitmap.height * scale).toInt()
        
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        
        val bytesWidth = targetWidth / 8
        val resultList = mutableListOf<Byte>()

        // ESC/POS "GS v 0 m xL xH yL yH d1...dk" Command header
        // m = 0 (Normal mode)
        // xL, xH = width in bytes (width in pixels / 8)
        // yL, yH = height in pixels
        val xL = (bytesWidth % 256).toByte()
        val xH = (bytesWidth / 256).toByte()
        val yL = (targetHeight % 256).toByte()
        val yH = (targetHeight / 256).toByte()

        resultList.addAll(listOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH).map { it.toByte() })

        // Convert pixel by pixel to bit stream (1 for black/dark, 0 for white/light)
        for (y in 0 until targetHeight) {
            for (xByte in 0 until bytesWidth) {
                var currentByte = 0
                for (bit in 0 until 8) {
                    val xPixel = xByte * 8 + bit
                    val pixelColor = scaledBitmap.getPixel(xPixel, y)
                    
                    val red = Color.red(pixelColor)
                    val green = Color.green(pixelColor)
                    val blue = Color.blue(pixelColor)
                    val alpha = Color.alpha(pixelColor)

                    // Compute luminance (grayscale)
                    val luminance = (0.299 * red + 0.587 * green + 0.114 * blue).toInt()
                    
                    // Threshold thresholding: if dark or solid pixel, set bit to 1 (black)
                    if (alpha > 128 && luminance < 160) {
                        currentByte = currentByte or (1 shl (7 - bit))
                    }
                }
                resultList.add(currentByte.toByte())
            }
        }

        return resultList.toByteArray()
    }
}
