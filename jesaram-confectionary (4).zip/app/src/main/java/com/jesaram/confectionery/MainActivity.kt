package com.jesaram.confectionery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jesaram.confectionery.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val repository = Repository(applicationContext)

        setContent {
            JesaramTheme {
                // Persistent states loaded from repository
                var itemsList by remember { mutableStateOf(repository.getItems()) }
                var transactionsList by remember { mutableStateOf(repository.getTransactions()) }
                var appLanguage by remember { mutableStateOf(repository.getLanguage()) }

                var currentTab by remember { mutableStateOf("Sales") }

                Scaffold(
                    topBar = {
                        @OptIn(ExperimentalMaterial3Api::class)
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = if (appLanguage == "Urdu") "جیسارام کنفیکشنری پی او ایس" else "Jesaram Confectionery POS",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Text(
                                        text = if (appLanguage == "Urdu") "موبائل پوائنٹ آف سیل اور پرنٹر مینیجر" else "Mobile Point of Sale & Printer Manager",
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            val tabs = listOf(
                                Triple("Sales", if (appLanguage == "Urdu") "فروخت (Sales)" else "Sales", Icons.Default.ShoppingCart),
                                Triple("Transactions", if (appLanguage == "Urdu") "بل ریکارڈ" else "Transactions", Icons.Default.ReceiptLong),
                                Triple("Admin", if (appLanguage == "Urdu") "انتظامیہ" else "Admin", Icons.Default.AdminPanelSettings)
                            )

                            tabs.forEach { (tabKey, tabLabel, icon) ->
                                val isSelected = currentTab == tabKey
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tabKey },
                                    icon = { Icon(icon, contentDescription = tabLabel) },
                                    label = { Text(tabLabel, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.secondary,
                                        selectedTextColor = MaterialTheme.colorScheme.secondary,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            "Sales" -> SalesScreen(
                                itemsList = itemsList,
                                transactions = transactionsList,
                                appLanguage = appLanguage,
                                onLanguageChange = { newLang ->
                                    appLanguage = newLang
                                    repository.saveLanguage(newLang)
                                },
                                onAddTransaction = { newTx ->
                                    val updated = transactionsList + newTx
                                    transactionsList = updated
                                    repository.saveTransactions(updated)
                                    
                                    // Trigger continuous automated backup to Downloads folder on every transaction
                                    FileUtils.exportBackup(applicationContext, repository.getBackupDataJson())
                                }
                            )
                            "Transactions" -> TransactionsScreen(
                                transactions = transactionsList,
                                appLanguage = appLanguage
                            )
                            "Admin" -> AdminScreen(
                                itemsList = itemsList,
                                appLanguage = appLanguage,
                                onUpdateItems = { updated ->
                                    itemsList = updated
                                    repository.saveItems(updated)
                                    // Trigger continuous auto-backup on items change
                                    FileUtils.exportBackup(applicationContext, repository.getBackupDataJson())
                                },
                                onRestoreBackup = { restoredItems, restoredTxs ->
                                    itemsList = restoredItems
                                    transactionsList = restoredTxs
                                    repository.saveItems(restoredItems)
                                    repository.saveTransactions(restoredTxs)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
