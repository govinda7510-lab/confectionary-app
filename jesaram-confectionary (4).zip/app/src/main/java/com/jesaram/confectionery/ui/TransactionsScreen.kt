package com.jesaram.confectionery.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.annotation.SuppressLint
import android.widget.Toast
import com.jesaram.confectionery.*
import java.text.SimpleDateFormat
import java.util.*

@SuppressLint("MissingPermission")
@Composable
fun TransactionsScreen(
    transactions: List<ConfectioneryTransaction>,
    appLanguage: String
) {
    var searchQuery by remember { mutableStateOf("") }
    val expandedTxIds = remember { mutableStateListOf<String>() }
    
    var showPrinterSelectDialog by remember { mutableStateOf(false) }
    var selectedPrinterMac by remember { mutableStateOf("") }
    var txToPrint by remember { mutableStateOf<ConfectioneryTransaction?>(null) }

    val isUrdu = appLanguage == "Urdu"

    // Computations
    val filteredTx = transactions.filter {
        it.billNumber.contains(searchQuery, ignoreCase = true) ||
                it.paymentMethod.contains(searchQuery, ignoreCase = true) ||
                it.customerName.contains(searchQuery, ignoreCase = true)
    }.sortedByDescending { it.timestamp }

    val totalRevenue = transactions.sumOf { it.total }
    val totalOrders = transactions.size
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Analytics Row Cards (Grid-like)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isUrdu) "کل فروخت (Sales)" else "Total Sales", 
                        fontSize = 10.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Rs. ${totalRevenue.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isUrdu) "کل بل (Orders)" else "Orders", 
                        fontSize = 10.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(totalOrders.toString(), fontSize = 14.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Beautiful "Download All Transactions" Button
        Button(
            onClick = {
                if (transactions.isEmpty()) {
                    Toast.makeText(context, if (isUrdu) "ریکارڈ خالی ہے۔" else "No transactions to download", Toast.LENGTH_SHORT).show()
                } else {
                    val success = FileUtils.savePdfToDownloads(context, transactions)
                    if (success) {
                        Toast.makeText(context, if (isUrdu) "پی ڈی ایف رپورٹ ڈاؤن لوڈ ہو گئی ہے!" else "PDF Report downloaded successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Failed to download PDF Report", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF Report", modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isUrdu) "تمام ٹرانزیکشنز پی ڈی ایف ڈاؤن لوڈ کریں" else "Download All Transactions as PDF", 
                fontWeight = FontWeight.Bold, 
                fontSize = 13.sp
            )
        }

        // Search Transactions
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            placeholder = { 
                Text(
                    if (isUrdu) "بل، ادائیگی یا گاہک کے نام سے تلاش کریں..." else "Search transactions by bill/method...", 
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                ) 
            },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
        )

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), modifier = Modifier.padding(bottom = 8.dp))

        // History list
        if (filteredTx.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = "Empty receipts",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isUrdu) "کوئی ریکارڈ نہیں ملا۔" else "No sales registered yet.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTx, key = { it.id }) { tx ->
                    val isExpanded = expandedTxIds.contains(tx.id)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            .clickable {
                                if (isExpanded) {
                                    expandedTxIds.remove(tx.id)
                                } else {
                                    expandedTxIds.add(tx.id)
                                }
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = tx.billNumber,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (tx.customerName.isNotBlank()) {
                                        Text(
                                            text = "${if (isUrdu) "گاہک:" else "Cust:"} ${tx.customerName}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text(
                                        text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(tx.timestamp)),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                        modifier = Modifier.padding(end = 8.dp)
                                    ) {
                                        Text(
                                            text = "Rs. ${tx.total.toInt()}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                        Text(
                                            text = if (isUrdu && tx.paymentMethod == "Cash") "نقد" else tx.paymentMethod,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = "Toggle Expand",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Expanded view (Custom Receipt Detail)
                            AnimatedVisibility(
                                visible = isExpanded,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 12.dp)
                                        .background(Color(0xFFFFFDF9), RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    // Header
                                    Text(
                                        text = if (isUrdu) "جیسارام کنفیکشنری" else "JESARAM CONFECTIONERY",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Text(
                                        text = "-".repeat(32),
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Items lists
                                    tx.items.forEach { cartItem ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${cartItem.quantity} x ${cartItem.item.name}",
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "Rs. ${(cartItem.item.price * cartItem.quantity).toInt()}",
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    Text(
                                        text = "-".repeat(32),
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Calculations
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(if (isUrdu) "کل رقم:" else "Total:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                        Text("Rs. ${tx.total.toInt()}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Operations (Download, Save, Bluetooth Print!)
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    val success = FileUtils.savePdfToDownloads(context, listOf(tx))
                                                    if (success) {
                                                        Toast.makeText(context, if (isUrdu) "پی ڈی ایف ڈاؤنلوڈ ہو گیا!" else "Receipt PDF downloaded successfully!", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "Failed to download PDF", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isUrdu) "پی ڈی ایف" else "PDF", fontSize = 9.sp)
                                            }

                                            Button(
                                                onClick = {
                                                    val success = FileUtils.saveReceiptToGallery(context, tx, isUrdu = isUrdu)
                                                    if (success) {
                                                        Toast.makeText(context, if (isUrdu) "تصویر محفوظ ہو گئی!" else "Receipt JPG saved to Gallery!", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "Failed to save JPG image", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Icon(Icons.Default.Image, contentDescription = "Save JPG", modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isUrdu) "تصویر" else "Save JPG", fontSize = 9.sp)
                                            }
                                        }

                                        // Bluetooth Re-print trigger button
                                        Button(
                                            onClick = {
                                                if (!BluetoothPrinterHelper.hasBluetoothPermissions(context)) {
                                                    Toast.makeText(context, "Please grant Bluetooth permissions.", Toast.LENGTH_LONG).show()
                                                } else {
                                                    txToPrint = tx
                                                    showPrinterSelectDialog = true
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                                            contentPadding = PaddingValues(vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Bluetooth, contentDescription = "Print", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (isUrdu) "بلوٹوتھ پرنٹ کریں" else "Re-print via Bluetooth", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Bluetooth Printer Selector
    if (showPrinterSelectDialog) {
        val printers = BluetoothPrinterHelper.getPairedPrinters(context)
        AlertDialog(
            onDismissRequest = { showPrinterSelectDialog = false; txToPrint = null },
            title = { Text(if (isUrdu) "پرنٹر منتخب کریں" else "Select Bluetooth Printer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (printers.isEmpty()) {
                        Text(if (isUrdu) "کوئی پرنٹر نہیں ملا۔" else "No paired printers found.")
                    } else {
                        printers.forEach { device ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPrinterMac = device.address
                                        showPrinterSelectDialog = false
                                        txToPrint?.let { tx ->
                                            val bitmap = FileUtils.generateReceiptBitmap(tx, isUrdu = isUrdu)
                                            BluetoothPrinterHelper.printBitmap(context, device.address, bitmap) { status ->
                                                Toast.makeText(context, status, Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        txToPrint = null
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Print, contentDescription = "Printer", tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(device.name ?: "Unknown Printer", fontWeight = FontWeight.Bold)
                                    Text(device.address, fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Divider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrinterSelectDialog = false; txToPrint = null }) {
                    Text(if (isUrdu) "بند کریں" else "Close")
                }
            }
        )
    }
}
