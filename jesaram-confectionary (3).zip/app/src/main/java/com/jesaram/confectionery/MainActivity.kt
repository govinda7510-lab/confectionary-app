package com.jesaram.confectionery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jesaram.confectionery.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val repository = Repository(applicationContext)

        setContent {
            JesaramTheme {
                // Persistent states loaded from repository
                var itemsList by remember { mutableStateOf(repository.getItems()) }
                var transactionsList by remember { mutableStateOf(repository.getTransactions()) }

                var currentTab by remember { mutableStateOf("Sales") }

                Scaffold(
                    topBar = {
                        @OptIn(ExperimentalMaterial3Api::class)
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = "Jesaram Confectionary POS",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Text(
                                        text = "Mobile Point of Sale & Printer Manager",
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            val tabs = listOf(
                                "Sales" to Icons.Default.ShoppingCart,
                                "Transactions" to Icons.Default.ReceiptLong,
                                "Admin" to Icons.Default.AdminPanelSettings
                            )

                            tabs.forEach { (tabName, icon) ->
                                val isSelected = currentTab == tabName
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tabName },
                                    icon = { Icon(icon, contentDescription = tabName) },
                                    label = { Text(tabName, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.secondary,
                                        selectedTextColor = MaterialTheme.colorScheme.secondary,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            "Sales" -> SalesScreen(
                                itemsList = itemsList,
                                transactions = transactionsList,
                                onAddTransaction = { newTx ->
                                    val updated = transactionsList + newTx
                                    transactionsList = updated
                                    repository.saveTransactions(updated)
                                }
                            )
                            "Transactions" -> TransactionsScreen(
                                transactions = transactionsList
                            )
                            "Admin" -> AdminScreen(
                                itemsList = itemsList,
                                onUpdateItems = { updated ->
                                    itemsList = updated
                                    repository.saveItems(updated)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
