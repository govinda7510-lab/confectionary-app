package com.jesaram.confectionery

import java.util.UUID

data class ConfectioneryItem(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var price: Double,
    var category: String,
    val createdAt: String = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date())
)

data class CartItem(
    val item: ConfectioneryItem,
    var quantity: Int
)

data class ConfectioneryTransaction(
    val id: String = UUID.randomUUID().toString(),
    val billNumber: String,
    val items: List<CartItem>,
    val total: Double,
    val paymentMethod: String,
    val timestamp: Long = System.currentTimeMillis()
)


