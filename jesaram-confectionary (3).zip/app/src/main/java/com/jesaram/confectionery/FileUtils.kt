package com.jesaram.confectionery

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileUtils {

    fun saveReceiptToGallery(context: Context, tx: ConfectioneryTransaction): Boolean {
        val bitmap = generateReceiptBitmap(tx)
        val filename = "Receipt_${tx.billNumber}_${System.currentTimeMillis()}.jpg"
        
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/JesaramReceipts")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues) ?: return false

        try {
            val outputStream: OutputStream? = resolver.openOutputStream(imageUri)
            if (outputStream != null) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                outputStream.close()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(imageUri, contentValues, null, null)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    private fun generateReceiptBitmap(tx: ConfectioneryTransaction): Bitmap {
        val width = 500
        val itemLineHeight = 35
        val headerHeight = 180
        val txDetailsHeight = 110
        val itemsHeight = tx.items.size * itemLineHeight
        val summaryHeight = 100
        val footerHeight = 120
        val totalHeight = headerHeight + txDetailsHeight + itemsHeight + summaryHeight + footerHeight + 60
        
        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        
        // Background
        val bgPaint = Paint().apply {
            color = Color.parseColor("#FFFDF9")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), totalHeight.toFloat(), bgPaint)
        
        // Paints
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 24f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        
        val centerPaint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        
        val linePaint = Paint().apply {
            color = Color.GRAY
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        
        var y = 40f
        
        // 1. Header
        canvas.drawText("JESARAM CONFECTIONERY", (width / 2).toFloat(), y, titlePaint)
        y += 30f
        canvas.drawText("Thar Bazar Umerkot", (width / 2).toFloat(), y, centerPaint)
        y += 20f
        canvas.drawText("Tel: 03443411034", (width / 2).toFloat(), y, centerPaint)
        y += 25f
        
        // Divider
        canvas.drawLine(20f, y, (width - 20).toFloat(), y, linePaint)
        y += 25f
        
        // 2. Transaction details
        canvas.drawText("BILL: ${tx.billNumber}", 20f, y, boldPaint)
        y += 25f
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(tx.timestamp))
        canvas.drawText("DATE: $dateStr", 20f, y, textPaint)
        y += 25f
        canvas.drawText("METHOD: ${tx.paymentMethod}", 20f, y, textPaint)
        y += 25f
        
        // Divider
        canvas.drawLine(20f, y, (width - 20).toFloat(), y, linePaint)
        y += 25f
        
        // 3. Items
        tx.items.forEach { cartItem ->
            val name = if (cartItem.item.name.length > 20) cartItem.item.name.substring(0, 18) + ".." else cartItem.item.name
            val qtyAndName = "${cartItem.quantity} x $name"
            canvas.drawText(qtyAndName, 20f, y, textPaint)
            
            val priceStr = "Rs. ${(cartItem.item.price * cartItem.quantity).toInt()}"
            val priceWidth = textPaint.measureText(priceStr)
            canvas.drawText(priceStr, (width - 20).toFloat() - priceWidth, y, textPaint)
            y += itemLineHeight
        }
        
        // Divider
        canvas.drawLine(20f, y, (width - 20).toFloat(), y, linePaint)
        y += 25f
        
        // 4. Summary
        canvas.drawText("TOTAL:", 20f, y, boldPaint)
        val totalStr = "Rs. ${tx.total.toInt()}"
        val totalWidth = boldPaint.measureText(totalStr)
        canvas.drawText(totalStr, (width - 20).toFloat() - totalWidth, y, boldPaint)
        y += 35f
        
        // Divider
        canvas.drawLine(20f, y, (width - 20).toFloat(), y, linePaint)
        y += 30f
        
        // 5. Footer
        canvas.drawText("Thank you for making your day sweeter! ♥", (width / 2).toFloat(), y, centerPaint)
        y += 20f
        canvas.drawText("Visit us again at Jesaram Confectionery", (width / 2).toFloat(), y, centerPaint)
        
        return bitmap
    }

    fun savePdfToDownloads(context: Context, transactions: List<ConfectioneryTransaction>): Boolean {
        if (transactions.isEmpty()) return false
        
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas
        
        val paint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        
        val headerPaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }
        
        var y = 50f
        
        // Draw Header
        canvas.drawText("JESARAM CONFECTIONERY - SALES REPORT", 50f, y, titlePaint)
        y += 20f
        val dateExported = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        canvas.drawText("Report Generated: $dateExported", 50f, y, paint)
        y += 15f
        canvas.drawText("Location: Thar Bazar Umerkot | Tel: 03443411034", 50f, y, paint)
        y += 30f
        
        // Table Headers
        canvas.drawText("Bill No", 50f, y, headerPaint)
        canvas.drawText("Date/Time", 180f, y, headerPaint)
        canvas.drawText("Payment", 320f, y, headerPaint)
        canvas.drawText("Amount", 450f, y, headerPaint)
        y += 8f
        canvas.drawLine(50f, y, 545f, y, linePaint)
        y += 20f
        
        var pageNumber = 1
        
        transactions.sortedByDescending { it.timestamp }.forEach { tx ->
            if (y > 750f) {
                pdfDocument.finishPage(page)
                pageNumber++
                val newPageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
                page = pdfDocument.startPage(newPageInfo)
                canvas = page.canvas
                y = 50f
                
                // Table Headers
                canvas.drawText("Bill No", 50f, y, headerPaint)
                canvas.drawText("Date/Time", 180f, y, headerPaint)
                canvas.drawText("Payment", 320f, y, headerPaint)
                canvas.drawText("Amount", 450f, y, headerPaint)
                y += 8f
                canvas.drawLine(50f, y, 545f, y, linePaint)
                y += 20f
            }
            
            canvas.drawText(tx.billNumber, 50f, y, paint)
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(tx.timestamp))
            canvas.drawText(dateStr, 180f, y, paint)
            canvas.drawText(tx.paymentMethod, 320f, y, paint)
            canvas.drawText("Rs. ${tx.total.toInt()}", 450f, y, paint)
            
            y += 8f
            canvas.drawLine(50f, y, 545f, y, linePaint)
            y += 20f
        }
        
        // Total Summary
        val totalRev = transactions.sumOf { it.total }
        if (y > 700f) {
            pdfDocument.finishPage(page)
            pageNumber++
            val newPageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
            page = pdfDocument.startPage(newPageInfo)
            canvas = page.canvas
            y = 50f
        }
        
        y += 10f
        canvas.drawLine(50f, y, 545f, y, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f })
        y += 25f
        canvas.drawText("TOTAL TRANSACTIONS: ${transactions.size}", 50f, y, headerPaint)
        val totalRevStr = "TOTAL REVENUE: Rs. ${totalRev.toInt()}"
        canvas.drawText(totalRevStr, 450f, y, headerPaint)
        
        pdfDocument.finishPage(page)
        
        val filename = "Sales_Report_${System.currentTimeMillis()}.pdf"
        
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Files.getContentUri("external")
        }
        
        val documentUri = resolver.insert(collection, contentValues) ?: return false
        
        return try {
            val outputStream = resolver.openOutputStream(documentUri)
            if (outputStream != null) {
                pdfDocument.writeTo(outputStream)
                outputStream.close()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(documentUri, contentValues, null, null)
            }
            pdfDocument.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            false
        }
    }
}
